package data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//파일관리:read,write 기능 실행


public class DataAccessObject {
	FileReader reader;
	BufferedReader bReader;
	FileWriter writer;
	BufferedWriter bWriter;
	String[] fileInfo = {"D:\\firebase\\database\\All menu.txt",
						"D:\\firebase\\database\\All restaurant.txt",
						"D:\\firebase\\database\\All order.txt"};



	public DataAccessObject() {

	}//▼해당 파일의 전체를 불러온다.
	private String[] fileReading(int index, int roomSize){
		String[] source = new String[roomSize];
		try {
			reader = new FileReader(this.fileInfo[index]);
			bReader = new BufferedReader(reader);
			int record = 0;
			while((source[record] = bReader.readLine())!=null) { // \n가 안나올때까지 반복한다 
				record++;
			}
			/*배열변수에 데이터 배치(index : 0,2,3), 패턴 파악이 핵심
				System.out.println(line.length); 1,김치찌개,13000  3개
				System.out.println(menu.length); 메뉴는 100개? //이중배열*/
			//1번 레코드에 전체 길이를 출력한다

		}
		catch (Exception e) {
			e.printStackTrace();
		}finally{ //StringBuffer 공간 효율을 위해...?
			try{
				bReader.close(); 
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		return source;
	}

	public void getMenu( String word, String[][] menu) {
		String[] source = this.fileReading(0, menu.length); //fileReading메서드에 해당 파일의 전체 내용 수집 요청
		int menuIndex = -1;
		for(int record=0; record<source.length; record++) {
			if(source[record] !=null) {
				if(source[record].contains(word)) {
					//split
					menuIndex++;
					menu[menuIndex][0] = source[record].split(",")[0];
					menu[menuIndex][2] = source[record].split(",")[1];
					menu[menuIndex][3] = source[record].split(",")[2];
				}
			}
		}
	}

	public void getStore(String[][] menu) {
		String[] source = this.fileReading(1, menu.length);
		// 1 명동찌개 강북 010-2111-6304
		for(int record=0; record<menu.length; record++){
			if(menu[record][0]!=null) {
				for(int index=0; index<source.length; index++) {
					if(source[index]!=null) {
						String[] line = source[index].split(",");
						if(menu[record][0].equals(line[0])) {
							menu[record][1]=line[1];
							menu[record][4]=line[2];
							break;
						}
					}
				}
			}
		}
	}
	public void getValue() {
		
	}
	
	public boolean getDate(String storecode, String compareDate) {
		//같은 날짜면 false   없으면 true
	
		 return false;
	}
	
}

/*Java IO
 *  BufferedReader Class
 *   + FlieReader(file_name)--> 음절단위로 읽음.
 *   + InputStream(file_name)--> byte단위로 읽음.
 *  BufferedWriter Class
 *   + FlieReader(file_name)--> 음절단위로 기록.
 *   + OutputStream
 * */
/*Variable--> 파괴성, 한번에 하나의 데이터만 저장(새로운 데이터 들어오면 기존 데이터 지워진다)
 * Array --> 여러개의 데이터를 하나의 참조변수로 접근 가능하게 하는 기술
 * index
 * */

