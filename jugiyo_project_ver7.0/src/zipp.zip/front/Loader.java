package front;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Loader {

	public static void main(String[] args) {
		new Client();

	}

}
